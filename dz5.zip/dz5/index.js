// Отримання чисел від користувача через prompt
var number1 = parseFloat(prompt("Введіть перше число:"));
var number2 = parseFloat(prompt("Введіть друге число:"));
var number3 = parseFloat(prompt("Введіть третє число:"));

// Обчислення середнього арифметичного
var average = (number1 + number2 + number3) / 3;

// Відображення результату за допомогою alert
alert("Середнє арифметичне чисел: " + average);